Rambo Theme README.

A Business Blog theme that supports Primary menu's , Primary sidebar,Three widgets area at the footer region  etc. 
It has a perfect design that's great for any Business/Firms  Blogs who wants a new look for their site. 
Rambo supports featured slider managed from Theme Option Panel.

Author: Webriti


About:
Rambo a theme for business, consultancy firms etc  by Webriti (Author URI: http://www.webriti.com). 

The CSS, XHTML and design is released under GPL:
http://www.opensource.org/licenses/gpl-license.php

Feel free to use as you please. I would be very pleased if you could keep the Auther-link in the footer. Thanks and enjoy.

Appoinment supports Custom Menu, Widgets and 
the following extra features:

 - Pre-installed menu and content colors
 - Responsive
 - Custom sidebars
 - Support for post thumbnails
 - Similar posts feature
 - 3 widgetized areas in the footer
 - Customise Front Page 
 - Custom footer
 - Translation Ready 
 

# Basic Setup of the Theme.
-----------------------------------
Fresh installation!

1. Upload the Rambo Theme folder to your wp-content/themes folder.
2. Activate the theme from the WP Dashboard.
3. Done!
=== Images ===

All images in Rambo are licensed under the terms of the GNU GPL.

# Top Navigation Menu:
- Default the page-links start from the left! Use the Menus function in Dashboard/Appearance to rearrange the buttons and build your own Custom-menu. DO NOT USE LONG PAGE NAMES, Maximum 14 letters/numbers incl. spaces!
- Read more here: http://codex.wordpress.org/WordPress_Menu_User_Guide

=============Setting Option Panel======================
$$$$$$ Homepage Setting $$$$$$


1. Disable Front Page:- BY Defalult the themes customize Front page is displayed when the theme  installed for the first time.
			If you want to enable wordpress reading settinsg than disable this option.

2. Adding Logo:-	Upload the site logo from here also you can adjust the width and height of logo from the logo height and width fields.

3.Text Title as a logo:-  If just want to show text title instead of image logo than enable this setting and some text to the wordpress Site Title.

4.Custom Favicon:- 	Theme also support favicons. You can add your own favicon ico from here Please make sure thatyou only upload .ico image type.

5. Custom Css:-  	This is the nice feature added along with the theme, you can add your style rules form here. No need to use thirdparty plugin for doing so.


$$$$$$$ Service Section $$$$$$$$
1.Enable Service Section:- Service Section is found on the custom front page. This setting is on by default. If you dont want to show service section on front page 
			   Than disable this option.In the lite verison you are only allowed to add 4 services.

2.Service Icon:-	Font Awesome service icons are used here. Just specify the font awesoe icon name.

3.Service Title:-	Set Service Title here.

4. Service Description :-  Add information related to services.

Similarly  add more services.

$$$$ Footer Setting $$$$$
1. Enable/Disable footer Widgets:-  As the name suggest this setting will add an extra bit of functionality to add / remove widgets feature.

2. Credit Links:-  From the footer settings you can set the credit links like copyright, powered bye tc. If you dont want to use designed by link
		   than leave that option as blank. 


Support
-------

Do you enjoy this theme? Send your ideas - issues - on the theme formn . Thank you!

ChangLog
@Version: 1.0.6
Comperison Tab added in options Panel.
@Version: 1.0.5
Some Small bug fixed.
@Version: 1.0.4
->Added font references.
@Version: 1.0.3
->Removed jquery,Used Wp's jQuery.
@Version: 1.0.2
->Default CSS enqueued in scripts.php
->Screenshot size changed  
@Version 1.0
released

# --- EOF --- #
